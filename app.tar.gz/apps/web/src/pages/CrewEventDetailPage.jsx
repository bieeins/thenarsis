import React, { useState, useEffect } from 'react';
import { Helmet } from 'react-helmet';
import { useParams, useNavigate } from 'react-router-dom';
import { format, parseISO } from 'date-fns';
import { ArrowLeft, Calendar, MapPin, User, Phone, Package, FileText, CheckCircle2, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button.jsx';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card.jsx';
import { Checkbox } from '@/components/ui/checkbox.jsx';
import { Skeleton } from '@/components/ui/skeleton.jsx';
import { toast } from 'sonner';
import pb from '@/lib/pocketbaseClient.js';
import NotesSection from '@/components/NotesSection.jsx';

const CrewEventDetailPage = () => {
  const { eventId } = useParams();
  const navigate = useNavigate();
  const [assignment, setAssignment] = useState(null);
  const [loading, setLoading] = useState(true);
  const [confirming, setConfirming] = useState(false);
  const [isAttending, setIsAttending] = useState(false);

  useEffect(() => {
    fetchEventDetails();
  }, [eventId]);

  const fetchEventDetails = async () => {
    try {
      setLoading(true);
      const record = await pb.collection('crew_assignments').getOne(eventId, {
        expand: 'order_id,order_id.product_id',
        $autoCancel: false
      });
      setAssignment(record);
      setIsAttending(record.attendance_confirmation || false);
    } catch (error) {
      console.error('Error fetching event details:', error);
      toast.error('Failed to load event details');
      navigate('/crew-calendar');
    } finally {
      setLoading(false);
    }
  };

  const handleAttendanceConfirm = async () => {
    try {
      setConfirming(true);
      await pb.collection('crew_assignments').update(eventId, {
        attendance_confirmation: isAttending,
        attendance_status: isAttending ? 'confirmed' : 'pending'
      }, { $autoCancel: false });
      
      toast.success('Attendance status updated');
      fetchEventDetails();
    } catch (error) {
      console.error('Error updating attendance:', error);
      toast.error('Failed to update attendance');
    } finally {
      setConfirming(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-muted/30 py-8 px-4">
        <div className="max-w-4xl mx-auto space-y-6">
          <Skeleton className="h-10 w-32" />
          <Skeleton className="h-64 w-full rounded-2xl" />
          <Skeleton className="h-48 w-full rounded-2xl" />
        </div>
      </div>
    );
  }

  if (!assignment || !assignment.expand?.order_id) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-2xl font-bold mb-2">Event Not Found</h2>
          <Button onClick={() => navigate('/crew-calendar')}>Back to Calendar</Button>
        </div>
      </div>
    );
  }

  const order = assignment.expand.order_id;
  const product = order.expand?.product_id;

  return (
    <>
      <Helmet>
        <title>{order.event_name} - Event Details</title>
      </Helmet>
      <div className="min-h-screen bg-muted/30 py-8">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          
          <Button variant="ghost" onClick={() => navigate(-1)} className="mb-6 -ml-4 text-muted-foreground hover:text-foreground">
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back
          </Button>

          <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-8">
            <div>
              <h1 className="text-3xl font-extrabold tracking-tight">{order.event_name}</h1>
              <div className="flex items-center gap-3 mt-2 text-muted-foreground">
                <span className="flex items-center gap-1"><Calendar className="w-4 h-4" /> {format(parseISO(order.event_date), 'PPP')}</span>
                <span className="flex items-center gap-1"><MapPin className="w-4 h-4" /> {order.event_location}</span>
              </div>
            </div>
            <span className={`px-3 py-1 rounded-full text-sm font-semibold ${
              assignment.attendance_status === 'confirmed' ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-900/30 dark:text-emerald-400' :
              assignment.attendance_status === 'completed' ? 'bg-blue-100 text-blue-800 dark:bg-blue-900/30 dark:text-blue-400' :
              'bg-amber-100 text-amber-800 dark:bg-amber-900/30 dark:text-amber-400'
            }`}>
              {assignment.attendance_status?.toUpperCase() || 'PENDING'}
            </span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
            <Card className="md:col-span-2 shadow-sm border-border/60">
              <CardHeader>
                <CardTitle className="text-lg flex items-center gap-2">
                  <FileText className="w-5 h-5 text-primary" /> Event Details
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                  <div className="space-y-1">
                    <p className="text-sm text-muted-foreground flex items-center gap-2"><User className="w-4 h-4" /> Customer</p>
                    <p className="font-medium">{order.customer_name}</p>
                  </div>
                  <div className="space-y-1">
                    <p className="text-sm text-muted-foreground flex items-center gap-2"><Phone className="w-4 h-4" /> Contact</p>
                    <p className="font-medium">{order.phone_number}</p>
                  </div>
                  <div className="space-y-1">
                    <p className="text-sm text-muted-foreground flex items-center gap-2"><Package className="w-4 h-4" /> Package</p>
                    <p className="font-medium">{product?.package_name || 'Custom Package'}</p>
                  </div>
                </div>

                {order.description && (
                  <div className="pt-4 border-t">
                    <p className="text-sm text-muted-foreground mb-2">Description</p>
                    <div className="prose prose-sm dark:prose-invert max-w-none" dangerouslySetInnerHTML={{ __html: order.description }} />
                  </div>
                )}
                
                {order.designer_notes && (
                  <div className="pt-4 border-t">
                    <p className="text-sm text-muted-foreground mb-2">Designer Notes</p>
                    <div className="prose prose-sm dark:prose-invert max-w-none bg-muted/50 p-4 rounded-lg" dangerouslySetInnerHTML={{ __html: order.designer_notes }} />
                  </div>
                )}
              </CardContent>
            </Card>

            <div className="space-y-6">
              <Card className="shadow-sm border-border/60 bg-primary/5 border-primary/20">
                <CardHeader>
                  <CardTitle className="text-lg flex items-center gap-2">
                    <CheckCircle2 className="w-5 h-5 text-primary" /> Attendance
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <p className="text-sm text-muted-foreground">Please confirm your attendance for this event.</p>
                  <div className="flex items-center space-x-2 bg-background p-3 rounded-lg border">
                    <Checkbox 
                      id="attendance" 
                      checked={isAttending}
                      onCheckedChange={setIsAttending}
                    />
                    <label
                      htmlFor="attendance"
                      className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70 cursor-pointer"
                    >
                      I confirm I will attend (Hadir)
                    </label>
                  </div>
                  <Button 
                    className="w-full" 
                    onClick={handleAttendanceConfirm}
                    disabled={confirming || isAttending === assignment.attendance_confirmation}
                  >
                    {confirming ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : null}
                    Update Status
                  </Button>
                </CardContent>
              </Card>
            </div>
          </div>

          <Card className="shadow-sm border-border/60">
            <CardContent className="p-6">
              <NotesSection orderId={order.id} />
            </CardContent>
          </Card>

        </div>
      </div>
    </>
  );
};

export default CrewEventDetailPage;