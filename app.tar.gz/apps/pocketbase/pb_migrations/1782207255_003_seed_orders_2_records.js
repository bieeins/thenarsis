/// <reference path="../pb_data/types.d.ts" />
migrate((app) => {
  const collection = app.findCollectionByNameOrId("orders");

  const record0 = new Record(collection);
    record0.id = "co5dx6b3akxbzne";
    record0.set("customer_name", "TESTa");
    record0.set("phone_number", "0812345678");
    record0.set("event_name", "ANITA WEDDING");
    record0.set("event_date", "2026-06-27");
    record0.set("event_location", "Rumah");
    const record0_product_idLookup = app.findFirstRecordByFilter("products", "id != ''");
    if (!record0_product_idLookup) { throw new Error("Lookup failed for product_id: no record in 'products' matching \"id != ''\""); }
    record0.set("product_id", record0_product_idLookup.id);
    record0.set("status", "Pending");
  try {
    app.save(record0);
  } catch (e) {
    if (e.message.includes("Value must be unique")) {
      console.log("Record with unique value already exists, skipping");
    } else {
      throw e;
    }
  }

  const record1 = new Record(collection);
    record1.id = "b1uxkx2zrfnde2z";
    record1.set("customer_name", "Borneo EO");
    record1.set("phone_number", "0898765432");
    record1.set("event_name", "Gathering Samsung");
    record1.set("event_date", "2026-06-30");
    record1.set("event_location", "Prime Park Hotel");
    const record1_product_idLookup = app.findFirstRecordByFilter("products", "id != ''");
    if (!record1_product_idLookup) { throw new Error("Lookup failed for product_id: no record in 'products' matching \"id != ''\""); }
    record1.set("product_id", record1_product_idLookup.id);
    record1.set("status", "Completed");
  try {
    app.save(record1);
  } catch (e) {
    if (e.message.includes("Value must be unique")) {
      console.log("Record with unique value already exists, skipping");
    } else {
      throw e;
    }
  }
}, (app) => {
  const seededRecordIds = ["b1uxkx2zrfnde2z", "co5dx6b3akxbzne"];
  for (const seededRecordId of seededRecordIds) {
    try {
      app.delete(app.findRecordById("orders", seededRecordId));
    } catch (error) {
      if (error.message.includes("no rows in result set")) {
        continue;
      }
      throw error;
    }
  }
})